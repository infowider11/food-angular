
		
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
		
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="https://dexignzone.com/" target="_blank">DexignZone</a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->
		
        <!--**********************************
           Support ticket button end
        ***********************************-->


	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?= base_url('assets/vendor/global/global.min.js'); ?>"></script>
     <script src="<?= base_url('assets/vendor/bootstrap-select/dist/js/bootstrap-select.min.js'); ?>"></script>
	<script src="<?= base_url('assets/vendor/jquery-nice-select/js/jquery.nice-select.min.js'); ?>"></script>
     <script src="<?= base_url('assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?= base_url('assets/js/plugins-init/datatables.init.js'); ?>"></script>

	<script src="<?= base_url('assets/vendor/chart.js/Chart.bundle.min.js'); ?>"></script>
	<script src="<?= base_url('assets/vendor/apexchart/apexchart.js'); ?>"></script>
    <script src="<?= base_url('assets/vendor/peity/jquery.peity.min.js'); ?>"></script>
	<script src="<?= base_url('assets/js/dashboard/dashboard-1.js'); ?>"></script>
    <script src="<?= base_url('assets/js/custom.min.js'); ?>"></script>
    <script src="<?= base_url('assets/js/deznav-init.js'); ?>"></script>
	<script src="<?= base_url('assets/js/demo.js'); ?>"></script>
   <!--  <script src="<?= base_url('assets/js/owl.carousel.min.js'); ?>"></script>
    <script src="<?= base_url('assets/js/bootstrap.bundle.min.js'); ?>"></script> -->

    <script src="<?= base_url('assets/js/styleSwitcher.js'); ?>"></script>
    <script src="<?= base_url('assets/vendor/lightgallery/js/lightgallery-all.min.js'); ?>"></script>
    <script src="https://cloud.tinymce.com/5/tinymce.min.js?apiKey=y8edi4divxwsplcdd28rzuyx245zbzdndm22yzhuaanemki5"></script>
<script>tinymce.init({ selector: '.textarea', height:480, plugins: [  "advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste" ], toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image", setup: function (editor) { editor.on('change', function () { tinymce.triggerSave(); }); }});</script>
    
</body>
</html>



